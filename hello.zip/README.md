
<!DOCTYPE html>
<html>
<head>
<title> Home </title>
<link rel="stylesheet" type="text/css" href="popstyle.css">
</head>
<body>
	<nav>
		<ul>
			<li><a href="#section1">Home</a></li>
			<li><a href="#section2">Movement</a></li>
			<li><a href="#section3">History</a></li>
			<li><a href="#section4">Info</a></li>
		</ul>
	</nav>
<center>
</br>
</br>
<h1>Pop Surrealism</h1>
</center>

</br>
</br>

<section id="section1">
<center>
	<img src="media/jean.jpg" height="350" width="400"/>

	<div class="text">
		Hello everyone!
		</br>
		The art movement I'd like to share about is
		</br>
		the rise of the Lowbrow aka Pop Surrealism movement.
		</br>
		</br>
		Besides the well known surrealist style, the 'pop' in
		</br>
		pop surrealism focuses more on modern pop culture
		</br>
		and combining everyday realities into a fantasy.
		</br>
		</br>
		Here are just a few references that showcase the creative artistic style.
	</div>
</center>
</section>
<div class="image-grid">
<img src="media/jean 3.jpg" height="500" width="550"/>
<img src="media/jean 2.jpg" height="500" width="750"/>
<img src="media/godzilla.jpg" height="500" width="500"/>

</div>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>


<center>
<p>
	These images share similar characteristics that define the
	</br>
	pop surrealism style. Such as the color palette that includes a main
	</br>
	variety of blues, oranges, reds, browns, grey and white.
	</br>
	However the range of tones and highlights contrast
	</br>
	to show case these etheral, breath taking images created by the
	</br>
	Taiwanese artist, James Jean.
</p>

</br>
<section id="section2">
<h2>Movement</h2> </section2>
	What makes the Lowbrow style seperate from the main branch of Surrealism?
	</br>
	</br>
	That would have to be the Pop Art inspired traits that exactly make up Pop Surrealism.
	</br>
	These terms are used interchangeably just as both art styles tend to as well to create this sub art genre.
	</br>
	These characteristics include a variety of bright colors, nonsensical physics,
	and dramatic proportions in skewed sceneries.
	</br>
	Just as it combines and takes inspiration from the unconscious dreams and the superficial mundane.
	</br>
	This movement takes that and combines it into satirical works immersed
	</br>
	into sublime imagery that addresses alot of political and social issues with a sense of humor.
	</br>
	 It is a populist art movement with its cultural roots in underground comix, punk music, tiki culture,
 	</br>
	 graffiti, and hot-rod cultures of the street.
	</br>

<section id="section3">
</br>
<h3>History</h3></section3>
	Lowbrow Pop Surrealism was a style of art that was heavily inspired by the popular culture
</br>
	of the 1960s and 1970s in America. Commonly referred to as a “retro” style, this movement was
</br>
	most commonly seen in the form of paintings, digital art, sculpture, collage, and even toys.
</br>
	It essentially was brought about by the 'street' culture of the underground visual artists prominently
</br>
	from Los Angeles, Califronia.
</br>
</br>
The movement was said to have been influenced by a variety of other 20th-century art movements including Dadaism,
</br>
Surrealism, and even Fauvism. Lowbrow Art was met with much skepticism and shock, as it was thought to mock and completely
</br>
dismantle all aspects of traditional art.
</br>
</br>
The first Pop Surrealism artist was Robert Williams, who was shortly followed by Gary Panter. Their early works were exhibited
</br>
at several alternative galleries in New York and Los Angeles and as they were unknown, their particular artistic approach was not
</br>
thought to be highbrow enough for the art world. As the movement grew, hundreds of artists began adopting the Lowbrow style, which
</br>
meant that more art galleries were starting to openly exhibit Lowbrow Art. This led to the very first formal Lowbrow gallery exhibition
</br>
taking place in 1992, which was designed to illustrate the significance of the art movement.
</br>
</br>
The term “Pop Surrealism” was eventually thought up by The Aldrich Contemporary Art Museum during a 1998 exhibit. The type of artworks on
</br>
display drew from a multitude of lowbrow concepts and was considered to be essentially Pop Surrealist in nature. As it developed into its own
</br>
distinctive art culture that was completely uninhibited by any creative rules, Pop Surrealism existed as a fusion between pop culture icons and
the ambiguity of the Surrealist style.
</br>
the most influential publication to come out of the Lowbrow Pop Surrealism movement was Juxtapoz magazine, which was created by Robert Williams in 1994.
</br>
 With the help of film producer Greg Escalante and skateboard designer Eric Swenson, Williams was able to come up with a magazine that communicated and
</br>
 validated what the Lowbrow Art movement stood for.

</br>
Juxtapoz was built on the philosophies and merits of the pop culture that had manifested itself in California during the 1970s. The magazine was also encouraged
</br>
by the freedom of artists who had broken away from the traditional customs that governed the conventional New York art world. Established with the mission to blend
</br>
modern cultural genres ranging from psychedelic art to graffiti and street art, Juxtapoz demonstrated great pride in its cultural roots and did not hesitate to show
</br>
 it in its publications like the Hi-fructose magazine.
</br>
</br>
As the movement has expanded, the cultural influences that have been associated with Lowbrow Pop Surrealism have also grown. In addition to underground comix as one of
</br>
the main characteristics for the art style, punk music, pulp art, “B” horror movies, Japanese anime, soft porn, icons of pop culture, and other subcultural contributions
</br>
were all sources of inspiration.
</br>
Today, Lowbrow Pop Surrealism is still practiced by several prominent artists. However, with the emergence of the new millennium, many artists began to make use of
</br>
computer-based tools, techniques, and software’s to create their Lowbrow artworks. Some very incredible artworks have been derived from programs like Adobe Photoshop and
</br>
the 3D modeling application called Maya. Being digital, these artworks have abandoned traditional artmaking principles, which makes them true examples of Lowbrow Art.




<section id="section4">
</br>
<h4>Extra Info</h4></section4>
The movement was said to have been influenced by a variety of other 20th-century art movements including Dadaism,
</br>
Surrealism, and even Fauvism. Lowbrow Art was met with much skepticism and shock, as it was thought to mock and completely
</br>
dismantle all aspects of traditional art.
</br>
The majority of these Lowbrow artists were not creatives by education. They were all self-taught artists whose artworks strayed far
</br>
	away from anything that could be considered and labeled as fine art.
</br>
Robert Williams coined the term the lowbrow movement, and the Juxtapoz magazine.
</br>
The original movement of Surrealism began in Europe after the end of World War One and was said to have developed in reaction to
</br>
the madness and violence that the war generated.
</br>
As a descendant of the famous Dada movement, Pop art brought a rebellious streak into the Lowbrow Pop Surrealist style.


</center>
</body>
</html>
